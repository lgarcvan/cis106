![profile_pic](pexels-life-of-pix-7974.jpg)

# Vanessa Garcia 

--- 

Passaic, NJ 07055 ◆ 555 555 5555 ◆ vgarcia-bermudez@students.pccc.edu

### Professional Summary
* Customer Service skill 
* Able to multitask
* Solve customer issue 

### Work History
Associate, 12/2022 to Amazon Warehouse,  NJ 
+ Attend to customer order
+ Manage returned items


#### Sale Assiciate, 11/2018 to 05/2021
Bookstore – Montclair, NJ

* Located products in the store and placed orders of out-of-stock items.
* Processed online orders
* Responded to customer requests for products, services and brand information.
  


### Skills 

| Technical   | Sale Associate        |
| ----------- | --------------------- |
| GIS Program | Over Phone resolution |
| HTML        | Sales expertise       |

### Education
| Degree           | School | Year    |
| ---------------- | ------ | ------- |
| Certificate      | PCCC   | current |
| Bachelors Degree | MSU    | 2020    |